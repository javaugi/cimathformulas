<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};
</#if>
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 *
 * @author ${user}
 * @version $LastChangedRevision $LastChangedDate
 * Last Modified Author: $LastChangedBy
 */
public class ${name} {
    private static final Logger log = LoggerFactory.getLogger(${name}.class);
}
