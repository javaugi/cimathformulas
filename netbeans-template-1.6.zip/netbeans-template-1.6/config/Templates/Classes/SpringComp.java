<#macro toUnderScore camelCase>
${camelCase?replace("(?<=[a-z0-9])[A-Z]|(?<=[a-zA-Z])[0-9]|(?<=[A-Z])[A-Z](?=[a-z])", "_$0", 'r')?upper_case}</#macro>

<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};
</#if>
import static <#if package?? && package != "">${package}.</#if>${name}.<@toUnderScore camelCase=name/>;
import java.io.Serializable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
import com.ciminc.Scopes;
import com.ciminc.Locator;

/**
 * @author ${user}
 */
@Component(value = <@toUnderScore camelCase=name/>)
@Scope(Scopes.BROWSER_TAB)
public class ${name} implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(${name}.class);
    public static final String <@toUnderScore camelCase=name/> = "${name?uncap_first}";

    @PostConstruct
    public void init() {
        log.debug("Creating: ${name?uncap_first}");
    }

    public static ${name} instance() {
        return Locator.locate(${name}.class);
    }
}
