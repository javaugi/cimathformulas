<#macro toUnderScore camelCase>
${camelCase?replace("(?<=[a-z0-9])[A-Z]|(?<=[a-zA-Z])[0-9]|(?<=[A-Z])[A-Z](?=[a-z])", "_$0", 'r')?upper_case}</#macro> 

<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};
</#if>
import static <#if package?? && package != "">${package}.</#if>${name}.<@toUnderScore camelCase=name/>;
import java.io.Serializable;
import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**  
 * @author ${user}
 */
@Name(<@toUnderScore camelCase=name/>)
@Scope(ScopeType.CONVERSATION)
@BypassInterceptors
public class ${name} implements Serializable {
    private static final Logger log = LoggerFactory.getLogger(${name}.class);
    public static final String <@toUnderScore camelCase=name/> = "${name?uncap_first}";
    public static final String <@toUnderScore camelCase=name/>_EXP = <#noparse>"#{" + </#noparse><@toUnderScore camelCase=name/><#noparse> + "}";</#noparse>
    /** Begin Injected Variables **/     
    /** End Injected Variables **/

    /** Begin Local Variables **/
    /** End Local Variables **/

    @Create
    public void init() {
        log.debug("Creating: ${name?uncap_first}");
    }

    public static ${name} instance() {
        return (${name}) Component.getInstance(<@toUnderScore camelCase=name/>, true);        
    }
}
